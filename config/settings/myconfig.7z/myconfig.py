
SE_SECRET_KEY = 'django-insecure-_zm3p9of5roomi&z49+9-t30tf!30w@dbmuz!w49xr6p_r^2fr'
SE_DATABASES_USER = 'knowhowfactory'
SE_DATABASES_PSWD = 'robotchicken'
SE_DATABASE_URL_RDS = 'upbitdatabase.cmjzt71elckx.ap-northeast-2.rds.amazonaws.com'
